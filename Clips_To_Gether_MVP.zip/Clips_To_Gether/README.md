# Clips To Gether
Private Python MVP for uploading videos and rendering vertical 9:16 clips.

## Requirements
- Python 3.10+
- FFmpeg installed and available as `ffmpeg`

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set OWNER_PASSWORD and APP_SECRET in .env
uvicorn app.main:app --host 127.0.0.1 --port 8765
```
Open http://127.0.0.1:8765.

This is the first working stage, not the complete AI platform. AI highlight detection, live clipping, face tracking, and real YouTube/Instagram publishing require additional models, platform credentials and testing. Keep the server behind HTTPS/VPN/firewall; do not expose it publicly without protection.
