class InstagramPublisher:
    def publish_reel(self, video_url, caption):
        raise NotImplementedError("Requires Instagram Professional account, Meta permissions, access token and publicly fetchable media URL.")

class YouTubePublisher:
    def upload_short(self, video_path, title, description=""):
        raise NotImplementedError("Requires Google OAuth consent and configured YouTube API credentials.")
