import shutil, subprocess
from app.config import OUTPUTS

def ffmpeg_ok():
    return shutil.which("ffmpeg") is not None

def render(source, output_name, start, duration):
    if not ffmpeg_ok():
        raise RuntimeError("FFmpeg is missing on this machine.")
    if start < 0 or duration < 1 or duration > 180:
        raise ValueError("Start must be >= 0 and duration must be 1-180 seconds.")
    out = OUTPUTS / output_name
    vf = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
    cmd = ["ffmpeg","-y","-ss",str(start),"-i",str(source),"-t",str(duration),"-vf",vf,
           "-c:v","libx264","-preset","veryfast","-crf","23","-c:a","aac","-b:a","128k",
           "-movflags","+faststart",str(out)]
    p = subprocess.run(cmd,capture_output=True,text=True,timeout=900)
    if p.returncode:
        raise RuntimeError((p.stderr or "FFmpeg failed")[-1500:])
    return out
