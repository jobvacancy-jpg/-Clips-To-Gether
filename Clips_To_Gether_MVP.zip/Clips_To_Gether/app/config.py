import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
BASE = Path(__file__).resolve().parent.parent
DATA = Path(os.getenv("DATA_DIR", BASE / "data")).resolve()
UPLOADS, OUTPUTS = DATA / "uploads", DATA / "outputs"
for folder in (DATA, UPLOADS, OUTPUTS):
    folder.mkdir(parents=True, exist_ok=True)
APP_NAME = os.getenv("APP_NAME", "Clips To Gether")
APP_SECRET = os.getenv("APP_SECRET", "CHANGE-ME")
OWNER_USERNAME = os.getenv("OWNER_USERNAME", "owner")
OWNER_PASSWORD = os.getenv("OWNER_PASSWORD", "change-me")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "2048"))
