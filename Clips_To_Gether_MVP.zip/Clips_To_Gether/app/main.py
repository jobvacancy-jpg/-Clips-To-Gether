import secrets
from pathlib import Path
from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException
from fastapi.responses import RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from app.config import APP_NAME, APP_SECRET, UPLOADS, OUTPUTS, MAX_UPLOAD_MB, OWNER_USERNAME, OWNER_PASSWORD
from app import database as store
from app.services.video import render, ffmpeg_ok

app = FastAPI(title=APP_NAME)
app.add_middleware(SessionMiddleware, secret_key=APP_SECRET, same_site="lax")
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")
ALLOWED = {".mp4",".mov",".mkv",".webm",".m4v"}

@app.on_event("startup")
def startup():
    store.init()

def owner(request):
    return request.session.get("owner") is True

def page(request, template, **kw):
    return templates.TemplateResponse(template, {"request":request,"app_name":APP_NAME,"signed":owner(request),"ffmpeg":ffmpeg_ok(),**kw})

@app.get("/")
def home(request: Request):
    if not owner(request): return RedirectResponse("/login",303)
    return page(request,"dashboard.html",videos=store.videos(),jobs=store.jobs())

@app.get("/login")
def login_page(request: Request):
    return page(request,"login.html",error=None)

@app.post("/login")
def login(request: Request, username: str=Form(...), password: str=Form(...)):
    if not (secrets.compare_digest(username,OWNER_USERNAME) and secrets.compare_digest(password,OWNER_PASSWORD)):
        return page(request,"login.html",error="Username or password is incorrect.")
    request.session.clear()
    request.session["owner"] = True
    return RedirectResponse("/",303)

@app.post("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login",303)

@app.post("/upload")
async def upload(request: Request, video: UploadFile=File(...)):
    if not owner(request): raise HTTPException(401,"Login required")
    suffix=Path(video.filename or "").suffix.lower()
    if suffix not in ALLOWED: raise HTTPException(400,"Use MP4, MOV, MKV, WEBM or M4V.")
    name=secrets.token_hex(12)+suffix
    dest=UPLOADS/name
    total=0
    try:
        with dest.open("wb") as out:
            while chunk := await video.read(1024*1024):
                total += len(chunk)
                if total > MAX_UPLOAD_MB*1024*1024: raise HTTPException(413,"Upload too large.")
                out.write(chunk)
    except Exception:
        dest.unlink(missing_ok=True)
        raise
    store.add_video(Path(video.filename).name,name)
    return RedirectResponse("/",303)

@app.post("/clip")
def create_clip(request: Request, video_id:int=Form(...), start:float=Form(0), duration:float=Form(30)):
    if not owner(request): raise HTTPException(401,"Login required")
    v=store.video(video_id)
    if not v: raise HTTPException(404,"Video not found")
    jid=store.add_job(video_id)
    try:
        output=f"clip_{jid}.mp4"
        render(UPLOADS/v["stored"],output,start,duration)
        store.finish_job(jid,"completed","Clip ready",output)
    except Exception as e:
        store.finish_job(jid,"failed",str(e)[:900])
    return RedirectResponse("/",303)

@app.get("/download/{jid}")
def download(request: Request,jid:int):
    if not owner(request): raise HTTPException(401,"Login required")
    for j in store.jobs():
        if j["id"]==jid and j["output"] and (OUTPUTS/j["output"]).exists():
            return FileResponse(OUTPUTS/j["output"],filename=j["output"],media_type="video/mp4")
    raise HTTPException(404,"Clip not found")

@app.get("/health")
def health():
    return {"status":"ok","ffmpeg":ffmpeg_ok(),"app":APP_NAME}
