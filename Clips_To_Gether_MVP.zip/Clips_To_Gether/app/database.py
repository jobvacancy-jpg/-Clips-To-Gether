import sqlite3
from datetime import datetime, timezone
from app.config import DATA

DB = DATA / "clips.db"

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init():
    with db() as c:
        c.execute("CREATE TABLE IF NOT EXISTS videos (id INTEGER PRIMARY KEY, filename TEXT, stored TEXT, added TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS jobs (id INTEGER PRIMARY KEY, video_id INTEGER, status TEXT, message TEXT, output TEXT, added TEXT)")

def add_video(filename, stored):
    with db() as c:
        cur = c.execute("INSERT INTO videos(filename,stored,added) VALUES(?,?,?)",
                        (filename, stored, datetime.now(timezone.utc).isoformat()))
        return cur.lastrowid

def videos():
    with db() as c:
        return c.execute("SELECT * FROM videos ORDER BY id DESC").fetchall()

def video(vid):
    with db() as c:
        return c.execute("SELECT * FROM videos WHERE id=?", (vid,)).fetchone()

def add_job(vid):
    with db() as c:
        cur = c.execute("INSERT INTO jobs(video_id,status,message,added) VALUES(?,?,?,?)",
                        (vid, "processing", "Rendering vertical video", datetime.now(timezone.utc).isoformat()))
        return cur.lastrowid

def finish_job(jid, status, message, output=None):
    with db() as c:
        c.execute("UPDATE jobs SET status=?,message=?,output=? WHERE id=?", (status,message,output,jid))

def jobs():
    with db() as c:
        return c.execute("SELECT jobs.*,videos.filename FROM jobs JOIN videos ON videos.id=jobs.video_id ORDER BY jobs.id DESC LIMIT 50").fetchall()
